
package Clases;

public record Product(String name, double precio, String categoria){
    
}