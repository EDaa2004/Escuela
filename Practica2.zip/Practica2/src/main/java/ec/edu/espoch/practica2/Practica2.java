
package ec.edu.espoch.practica2;

import Productos.Producto;
import java.util.ArrayList;

/**
 *
 * @author Efren Andi
 */
public class Practica2 {

    public static void main(String[] args) {
        ArrayList<Producto> productos = new ArrayList<>();
        
        productos.add(new Producto("lapto", 5, 5.5));
        productos.add(new Producto("Cama", 1, 100.00));
        productos.add(new Producto("telefono", 2, 500.00));
        productos.add(new Producto("mesa", 2, 25.00));
        productos.add(new Producto("escoba", 5, 25.00));
        productos.add(new Producto("Nose", 5, 541.5));
        productos.add(new Producto("Creoque", 1, 250.00));
        productos.add(new Producto("for", 2, 550.00));
        productos.add(new Producto("Neta", 2, 250.00));
        productos.add(new Producto("si", 5, 25.00));
        
        System.out.println(".......Imprimir datos Ingresados..........");
        for(Producto producto : productos){
            producto.datosGenerados();
        }
        //imprimir cuyo datos como precios sean mayores a 100$
        System.out.println(".............Datos depues de cambio solo valores mayores a 100$....");
        for(Producto producto : productos){
            if(producto.getPrecio()>=100){
                producto.datosGenerados();
            }
        
        }
        
        
    }
}
