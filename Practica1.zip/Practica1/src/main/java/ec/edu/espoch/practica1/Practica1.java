package ec.edu.espoch.practica1;

import Clases.Persona;
import java.util.ArrayList;

public class Practica1 {

    public static void main(String[] args) {
        //Crear objetos
        ArrayList<Persona> personas = new ArrayList<>();
        personas.add(new Persona("Efren", 18, "Masculino"));
        personas.add(new Persona("Joel", 25, "Femenino"));
        personas.add(new Persona("Jessica", 21, "Femenino"));
        personas.add(new Persona("Anderson", 20, "Masculino"));
        personas.add(new Persona("Luis", 25, "Masculino"));
        
        System.out.println("Imprimir datos ingresados");
        for(Persona persona : personas){
            persona.mostrarDatos();
        }
        int edadTotal = 0;
        for (Persona persona : personas) {
            edadTotal += persona.getEdad();
        }
        double edadPromedio = (double) edadTotal / 4;
        System.out.println("Edad promedio: " + edadPromedio);
        
        Persona menorEdad = personas.get(0); 
        for (Persona persona : personas) {
            if (persona.getEdad() < menorEdad.getEdad()) {
                menorEdad = persona;
            }
        }
        System.out.println("Persona más joven: " + menorEdad.getEdad() + " años, " + menorEdad.nombre);
    
    }
}
